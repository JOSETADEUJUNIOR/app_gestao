<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta charset="utf-8" />
  <title>systecnico</title>

  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

  <link rel="stylesheet" href="../Template/assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="../Template/assets/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../Template/plugins/toastr/toastr.min.css">
  <link rel="stylesheet" href="../Template/assets/css/fonts.googleapis.com.css" />
  <link rel="stylesheet" href="../Template/assets/css/jquery-ui.custom.min.css" />
  <link rel="stylesheet" href="../Template/assets/css/jquery.gritter.min.css" />
  <link rel="stylesheet" href="../Template/assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
  <link rel="stylesheet" href="../Template/assets/css/ace-skins.min.css" />
  <link rel="stylesheet" href="../Template/assets/css/ace-rtl.min.css" />
  <link rel="stylesheet" href="../Template/assets/css/estilo.css">

</head>
<style>
  /* some elements used in demo only */
  .spinner-preview {
    width: 100px;
    height: 100px;
    text-align: center;
    margin-top: 60px;
  }

  .dropdown-preview {
    margin: 0 5px;
    display: inline-block;
  }

  .dropdown-preview>.dropdown-menu {
    display: block;
    position: static;
    margin-bottom: 5px;
  }
  .login-layout{
    background: url('../Template/assets/images/fundo.jpg');
  }
</style>
<script src="../Template/assets/js/ace-extra.min.js"></script>
<!-- ace settings handler -->